﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.IO;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace 文字游戏
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {

            武将 刘备 = new 武将 { 姓名 = "刘备",
                                   力量值 =7,
                                   zuoqi =坐骑.h1,
                                   kaiJia =铠甲.k1,
                                   var_Attack = 坐骑.G_刘备 * 武器.G_刘备,
                                   var_Defence = 坐骑.F_刘备 * 铠甲.F_刘备 };


            武将 关羽 = new 武将 { 姓名 = "关羽",
                                    力量值 = 8,
                                    zuoqi = 坐骑.h2,
                                    kaiJia = 铠甲.k2,
                                    var_Attack = 坐骑.G_关羽 * 武器.G_关羽,
                                    var_Defence = 坐骑.F_关羽 * 铠甲.F_关羽 };


            武将 张飞 = new 武将 { 姓名 = "张飞",
                                    力量值 = 7,
                                    zuoqi = 坐骑.h3,
                                    kaiJia = 铠甲.k3,
                                    var_Attack = 坐骑.G_张飞 * 武器.G_张飞,
                                    var_Defence = 坐骑.F_张飞 * 铠甲.F_张飞 };

            武将 吕布 = new 武将 { 姓名 = "吕布",
                                    力量值 = 9,
                                    zuoqi = 坐骑.h4,
                                    kaiJia = 铠甲.k4,
                                    var_Attack = 坐骑.G_吕布 * 武器.G_吕布,
                                    var_Defence = 坐骑.F_吕布 * 铠甲.F_吕布 };

        public MainWindow()
        {
            InitializeComponent();


            刘备.攻击事件 += 攻击;
            吕布.攻击事件 += 攻击;
            张飞.攻击事件 += 攻击;
            关羽.攻击事件 += 攻击;

            刘备.被攻击事件 += 反击;
            吕布.被攻击事件 += 反击;
            张飞.被攻击事件 += 反击;
            关羽.被攻击事件 += 反击;
        }

        private void 攻击(object sender, Attack e)
        {
            武将 a = (武将)sender;

            string s1 = a.姓名 + "骑" + a.zuoqi + "穿" + a.kaiJia + "拿" + a.wuqi 
                + "攻击了" + e._姓名 + "造成了" + e.attack + "点伤害, " 
                + e._姓名 + "还剩余" + e.health + "血。";
            记录.Text += s1 + "\n";

            if (e.health <= 0)
            {
                string s2 = e._姓名 + "阵亡";
                记录.Text += s2 + "\n";
            }
        }


        private void 反击(object sender, BeAttacked e)
        {
            武将 a = (武将)sender;

            //被反击者若生命值为零，则无法继续反击
            if (a.生命值 > 0)
            {
                string s1 = a.姓名 + "骑" + a.zuoqi + "身穿" + a.kaiJia + "手拿" + a.wuqi 
                    + "反击了" + e._姓名 + "造成了" + e.attack + "点伤害, " 
                    + e._姓名 + "还剩余" + e.health + "血。";
                记录.Text += s1 + "\n";

                if (e.health <= 0)
                {
                    string s2 = e._姓名 + "阵亡";
                    记录.Text += s2 + "\n";
                }
            }

        }


        private void 刘备_Click(object sender, RoutedEventArgs e)
        {
            if (刘备.生命值 > 0)
            {
                红方.Content = 刘备.姓名;
            }
            else
            {
                MessageBox.Show(刘备.姓名 + "已战败！");
            }
             
        }

        private void 关羽_Click(object sender, RoutedEventArgs e)
        {
            if (关羽.生命值 > 0)
            {
                红方.Content = 关羽.姓名;
            }
            else
            {
                MessageBox.Show(关羽.姓名 + "已战败！");
            }

        }

        private void 张飞_Click(object sender, RoutedEventArgs e)
        {
            if (张飞.生命值 > 0)
            {
                红方.Content = 张飞.姓名;
            }
            else
            {
                MessageBox.Show(张飞.姓名 + "已战败！");
            }

        }

        private void 吕布_Click(object sender, RoutedEventArgs e)
        {
            if (吕布.生命值 > 0)
            {
                蓝方.Content = 吕布.姓名;
            }
            else
            {
                MessageBox.Show(吕布.姓名 + "已战败！");
            }

        }
        

        private void 出战_Click(object sender, RoutedEventArgs e)
        {
            if (红方.Content == 刘备.姓名 && 蓝方.Content == 吕布.姓名)
            {
                刘备.On杀人(吕布);
                红方.Content = null;
                蓝方.Content = null;
            }
            else if (红方.Content == 张飞.姓名 && 蓝方.Content == 吕布.姓名)
            {
                张飞.On杀人(吕布);

                红方.Content = null;
                蓝方.Content = null;
            }
            else if (红方.Content == 关羽.姓名 && 蓝方.Content == 吕布.姓名)
            {
                关羽.On杀人(吕布);

                红方.Content = null;
                蓝方.Content = null;
            }
            else
            {
                MessageBox.Show("武将不能为空！");
            }

            if (刘备.生命值 <= 0 && 关羽.生命值 <= 0&& 张飞.生命值 <= 0)
            {
                MessageBox.Show("曹刘联盟战败！");
            }
            else if (吕布.生命值 <= 0)
            {
                MessageBox.Show("董卓联盟战败！");
            }
        }

        private void 清空_Click(object sender, RoutedEventArgs e)
        {
            红方.Content = null;
            蓝方.Content = null;
            记录.Text = null;

        }
        

        private void 存档_Click(object sender, RoutedEventArgs e)
        {
            FileStream fs = File.Open(@"../../XX.DAT", 
                FileMode.Create, FileAccess.Write);
            BinaryWriter bw = new BinaryWriter(fs);
            bw.Write(刘备._生命值);
            bw.Write(关羽._生命值);
            bw.Write(张飞._生命值);
            bw.Write(吕布._生命值);
            bw.Close();
            fs.Close();
            MessageBox.Show("存档成功！");
        }

        private void 读档_Click(object sender, RoutedEventArgs e)
        {
            FileStream fo = File.Open(@"../../XX.DAT", 
                FileMode.Open, FileAccess.Read);
            BinaryReader br = new BinaryReader(fo);
            刘备._生命值 = br.ReadDouble();
            关羽._生命值 = br.ReadDouble();
            张飞._生命值 = br.ReadDouble();
            吕布._生命值 = br.ReadDouble();
            br.Close();
            fo.Close();
            MessageBox.Show("读档成功！");
        }
    }
}
