﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;


namespace 文字游戏
{
    //class WJ
    //{
        // Person
        public class Person
        {
            public string 姓名 { get; set; }//定义姓名
            public int 力量值 { get; set; }//定义力量值
            public double 生命值 = 100.0;//定义生命值
            public double _生命值
            {
                get { return 生命值; }
                set { 生命值 = value; }
            }
        }

        //武器
        public class 武器
        {
            public static string w1 = "刀";
            public static int G_刘备 = 8;
            public static string w2 = "剑";
            public static int G_关羽 = 12;
            public static string w3 = "矛";
            public static int G_张飞 = 10;
            public static string w4 = "戟";
            public static int G_吕布 = 15;
        }

        //坐骑
        public class 坐骑
        {
            public static string h1 = "白马";
            public static int G_刘备 = 3;
            public static int F_刘备 = 3;
            public static string h2 = "红马";
            public static int G_关羽 = 5;
            public static int F_关羽 = 4;
            public static string h3 = "黑马";
            public static int G_张飞 = 4;
            public static int F_张飞 = 4;
            public static string h4 = "灰马";
            public static int G_吕布 = 6;
            public static int F_吕布 = 5;
        }

        //铠甲
        public class 铠甲
        {
            public static string k1 = "铠甲1";
            public static int F_刘备 = 3;
            public static string k2 = "铠甲2";
            public static int F_关羽 = 3;
            public static string k3 = "铠甲3";
            public static int F_张飞 = 3;
            public static string k4 = "铠甲4";
            public static int F_吕布 = 3;
        }


        public class Attack : EventArgs
        {
            public string _姓名;
            public double health;
            public int _力量值;
            public string _Wuqi;
            public string _KaiJia;
            public string _Zuoqi;
            public int var_Att;
            public int var_Def;
            public double attack;
        }
        public class BeAttacked : EventArgs
        {
            public string _姓名;
            public double health;
            public int _力量值;
            public string _Wuqi;
            public string _KaiJia;
            public string _Zuoqi;
            public int var_Att;
            public int var_Def;
            public double attack;
        }


        //武将
        public class 武将 : Person
        {
            public string wuqi { get; set; }
            public string kaiJia { get; set; }
            public string zuoqi { get; set; }
            public int var_Attack { get; set; }
            public int var_Defence { get; set; }

            public event EventHandler<Attack> 攻击事件;
            public event EventHandler<BeAttacked> 被攻击事件;
            public void On杀人(武将 被攻击者)
            {

                Attack args = new Attack();
                args._姓名 = 被攻击者.姓名;
                args._力量值 = 被攻击者.力量值;
                args._Zuoqi = 被攻击者.zuoqi;
                args._KaiJia = 被攻击者.kaiJia;
                args._Wuqi = 被攻击者.wuqi;
                args.var_Att = 被攻击者.var_Attack;
                args.var_Def = 被攻击者.var_Defence;

                //计算攻击的伤害数值以及被害人的生命值
                double attack = this.力量值 * this.var_Attack / 被攻击者.var_Defence;
                args.attack = attack;
                被攻击者.生命值 = 被攻击者.生命值 - attack;
                args.health = 被攻击者.生命值;
                攻击事件?.Invoke(this, args);

                if (被攻击者.生命值 > 0)//被攻击的对象自动进行一次反击
                {
                    被攻击者.On被杀(this);
                }
            }

            public void On被杀(武将 攻击者)
            {
                BeAttacked args = new BeAttacked();
                args._姓名 = 攻击者.姓名;

                args._力量值 = 攻击者.力量值;
                args._Zuoqi = 攻击者.zuoqi;
                args._KaiJia = 攻击者.kaiJia;
                args._Wuqi = 攻击者.wuqi;
                args.var_Att = 攻击者.var_Attack;
                args.var_Def = 攻击者.var_Defence;

                //计算反击的伤害数值以及凶手的生命值
                double Attack = this.力量值 * this.var_Attack / 攻击者.var_Defence;
                args.attack = Attack;
                攻击者.生命值 = 攻击者.生命值 - Attack;
                args.health = 攻击者.生命值;
                被攻击事件?.Invoke(this, args);

            }

        }

    }

//}
